package com.example.binmatesmobile

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun goToHomeScreen(view: View) {
        //create intent. Takes in current context and next activity path
        val intent = Intent(this, HomeActivity::class.java)
        //Add data to the intent
//        val username = findViewById<EditText>(R.id.editText_main_username)
//        intent.putExtra("USERNAME_KEY", username.text)
        startActivity(intent) //pass the intent to the next activity
    }
}
